<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idbddeathinformer')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idbddeathinformer), array('view', 'id'=>$data->idbddeathinformer)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('informername')); ?>:</b>
	<?php echo CHtml::encode($data->informername); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('informeraddress')); ?>:</b>
	<?php echo CHtml::encode($data->informeraddress); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('personname')); ?>:</b>
	<?php echo CHtml::encode($data->personname); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dod')); ?>:</b>
	<?php echo CHtml::encode($data->dod); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('timeofdeath')); ?>:</b>
	<?php echo CHtml::encode($data->timeofdeath); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('idccsex')); ?>:</b>
	<?php echo CHtml::encode($data->idccsex); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('fhname')); ?>:</b>
	<?php echo CHtml::encode($data->fhname); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('crematorymethod')); ?>:</b>
	<?php echo CHtml::encode($data->crematorymethod); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('reasondeath')); ?>:</b>
	<?php echo CHtml::encode($data->reasondeath); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('idccreligion')); ?>:</b>
	<?php echo CHtml::encode($data->idccreligion); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('other')); ?>:</b>
	<?php echo CHtml::encode($data->other); ?>
	<br />

	*/ ?>

</div>