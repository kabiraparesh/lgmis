<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('idbdbirthinformer')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->idbdbirthinformer), array('view', 'id'=>$data->idbdbirthinformer)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('informername')); ?>:</b>
	<?php echo CHtml::encode($data->informername); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('informeraddress')); ?>:</b>
	<?php echo CHtml::encode($data->informeraddress); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('childname')); ?>:</b>
	<?php echo CHtml::encode($data->childname); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('dob')); ?>:</b>
	<?php echo CHtml::encode($data->dob); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('timeofbirth')); ?>:</b>
	<?php echo CHtml::encode($data->timeofbirth); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('idccsex')); ?>:</b>
	<?php echo CHtml::encode($data->idccsex); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('fathername')); ?>:</b>
	<?php echo CHtml::encode($data->fathername); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fathereducation')); ?>:</b>
	<?php echo CHtml::encode($data->fathereducation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('mothername')); ?>:</b>
	<?php echo CHtml::encode($data->mothername); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('idccreligion')); ?>:</b>
	<?php echo CHtml::encode($data->idccreligion); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('motheroccupation')); ?>:</b>
	<?php echo CHtml::encode($data->motheroccupation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fatheroccupation')); ?>:</b>
	<?php echo CHtml::encode($data->fatheroccupation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('deliverymethod')); ?>:</b>
	<?php echo CHtml::encode($data->deliverymethod); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('birthplace')); ?>:</b>
	<?php echo CHtml::encode($data->birthplace); ?>
	<br />

	*/ ?>

</div>